//
//  ViewController.swift
//  POC
//
//  Created by Rupesh on 18/01/23.
//

import UIKit
import CoreData
import KeychainSwift


class ViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var username: UITextField!
    
    @IBOutlet weak var label1: UILabel!
    
    @IBOutlet weak var passwordlogin: UITextField!
    var result = NSArray()
    
    var iconClick = false
    let imageicon = UIImageView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imageicon.image = UIImage(named: "closedeye")
        
        let contentView = UIView()
        contentView.addSubview(imageicon)
        
        contentView.frame = CGRect(x: 0, y: 0, width: UIImage(named: "closedeye")!.size.width, height: UIImage(named: "closedeye")!.size.height)
        imageicon.frame = CGRect(x: -10, y: 0, width: UIImage(named: "closedeye")!.size.width, height: UIImage(named: "closedeye")!.size.height)
        passwordlogin.rightView = contentView
        passwordlogin.rightViewMode = .always
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        imageicon.isUserInteractionEnabled = true
        imageicon.addGestureRecognizer(tapGestureRecognizer)
        
    }
    @objc func imageTapped(tapGestureRecognizer: UITapGestureRecognizer)
    {
        let tappedImage = tapGestureRecognizer.view as! UIImageView
        if iconClick
        {
            iconClick = false
            tappedImage.image = UIImage(named: "openeye")
            passwordlogin.isSecureTextEntry = false
        }
        else{
            iconClick = true
            tappedImage.image = UIImage(named: "closedeye")
            passwordlogin.isSecureTextEntry = true
        }
    }
    
    func showsignin(message: String){
        let alertController = UIAlertController(title: "Information", message: message, preferredStyle: .alert)
            let ok = UIAlertAction(title: "Ok", style: .default)
            alertController.addAction(ok)
            self.present(alertController, animated: true)
        
    }
    
    func signinalert(){
        if username.text == "" && passwordlogin.text == ""
            {
            showsignin(message: "Please enter all the fields")
            }
        else if username.text == "" && passwordlogin.text?.isEmpty == false
        {
            showsignin(message: "Please enter email")
        }
        else if username.text?.isEmpty == false && passwordlogin.text == ""
        {
            showsignin(message: "Please enter password")
        }
        
        else
            {
                self.Check(username : username.text! as String, password : passwordlogin.text! as String)
            }
    }
    
    
    @IBAction func login(_ sender: Any) {
        signinalert()
    }
        
        
        func Check( username: String, password : String)
        {
            let app = UIApplication.shared.delegate as! AppDelegate
            let context = app.persistentContainer.viewContext
            let fetchrequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Credentials")
           
            let predicate = NSPredicate(format: "email = %@", username, "password = %@", password)
            fetchrequest.predicate = predicate
            
            
//            let keychain = KeychainSwift()
//                keychain.accessGroup = "123ABCXYZ.iOSAppTemplates"
//            let userName = keychain.get("userName")
//            let passWord = keychain.get("password")
//
//            if userName == username && passWord == password{
//                let alert = UIAlertController(title: "Alert", message: "Login Successful", preferredStyle: .alert)
//                alert.addAction(UIAlertAction(title: "OK", style: .default, handler:{ (action) -> Void in
//
//                    let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
//                    let viewController3 = storyBoard.instantiateViewController(withIdentifier: "ViewController3") as! ViewController3
//                    self.navigationController?.pushViewController(viewController3, animated: true)
//
//
//            }
//                ))
//                alert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
//                present(alert, animated: true, completion:{
//                    return
//                })
//                print("Login Succesfully")
//            }
//            
//
            
            
            do
            {
                result = try context.fetch(fetchrequest) as NSArray
                if result.count>0
                {
                    let objectentity = result.firstObject as! Credentials
                    
                    if (objectentity.email == username && objectentity.password == password)
                    {
                        let alert = UIAlertController(title: "Alert", message: "Login Successful", preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "OK", style: .default, handler:{ (action) -> Void in
                        
                            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
                            let viewController3 = storyBoard.instantiateViewController(withIdentifier: "ViewController3") as! ViewController3
                            self.navigationController?.pushViewController(viewController3, animated: true)
                        
                                        
                    }
                        ))
                        alert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
                        present(alert, animated: true, completion:{
                            return
                        })
                        print("Login Succesfully")
                    }
                       
                    
                else
                    {
                        let alert = UIAlertController(title: "Alert", message: "Wrong username or password", preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        present(alert, animated: true, completion:{
                            return
                        })
                        print("Wrong username or password !!!")
                    }
                    
                    
                    let cData = try context.fetch(Credentials.fetchRequest()) as! [Credentials]
                    print("Data has been fetched successfully")
                    for data in cData{
                    print(data.email)
                    print(data.password)
                    print(data.name)
                    }
                    
                }
                else{
                    let alert = UIAlertController(title: "Alert", message: "Wrong username or password", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                    present(alert, animated: true, completion:{
                        return
                    })
                    print("Wrong username or password !!!")
                    
                }
            }

            catch
            {
                let fetch_error = error as NSError
                print("error", fetch_error.localizedDescription)
           
            }
        }

        
    
    @IBAction func forgotbtn(_ sender: Any) {
        
    }
    
    @IBAction func btn3(_ sender: Any) {
        
    }
    

    
}
    


