//
//  ViewController3.swift
//  POC
//
//  Created by Rupesh on 20/01/23.
//

import UIKit
import SDWebImage
import SDWebImageSVGKitPlugin



class ViewController3: UIViewController {
    
    @IBOutlet weak var searchBar: UISearchBar!
    
    @IBOutlet weak var tableView: UITableView!
    
    var fetchData = FetchData()
    var countryDataSpaces = [CountryData]()
    {
        didSet{
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
            
        }
    }
        
   
    override func viewDidLoad() {
        fetchData.fetchData{CountryDataArray in
            self.countryDataSpaces = CountryDataArray
        }
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        searchBar.delegate = self

        // Do any additional setup after loading the view.
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }

        searchBar.placeholder = "Search by Country Name"

    }
    
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        if segue.identifier == "DetailViewController" {
//            if let indexPath = self.tableView.indexPathForSelectedRow {
//                let controller = segue.destination as! DetailViewController
//                controller.name = countryDataSpaces[indexPath.row].name ?? "nil"
//                controller.code = countryDataSpaces[indexPath.row].code ?? "nil"
//                controller.unicode = countryDataSpaces[indexPath.row].unicode ?? "nil"
//
//                print(countryDataSpaces[indexPath.row].image)
//
//                let urlImage = URL(string: "\(countryDataSpaces[indexPath.row].image!)")
//                let svgCoder = SDImageSVGKCoder.shared
//                SDImageCodersManager.shared.addCoder(svgCoder)
//                let imageView = UIImageView()
//
//                imageView.sd_setImage(with: urlImage)
//                // this arg is optional, if don't provide, use the viewport size instead
//                let svgImageSize = CGSize(width: 100, height: 100)
//                imageView.sd_setImage(with: urlImage, placeholderImage: nil, options: [], context: [.imageThumbnailPixelSize : svgImageSize])
//                controller.image = imageView.image ?? UIImage(named: "empty") as! UIImage
//
//            }
//        }
//    }
}



extension ViewController3: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return countryDataSpaces.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! MyTableViewCell
        cell.nameLabel.text = countryDataSpaces[indexPath.row].name
        cell.codeLabel.text = countryDataSpaces[indexPath.row].code
        if let urlImage = URL(string: "\(countryDataSpaces[indexPath.row].image!)"){
            
            let svgCoder = SDImageSVGKCoder.shared
            SDImageCodersManager.shared.addCoder(svgCoder)
            
            
            cell.myimage.sd_imageIndicator = SDWebImageActivityIndicator.gray
            cell.myimage.sd_imageIndicator?.startAnimatingIndicator()
            let svgImageSize = CGSize(width: 100, height: 100)
            
            
            cell.myimage.sd_setImage(with: urlImage, placeholderImage: UIImage(named: "empty"), options: .continueInBackground, context: [.imageThumbnailPixelSize : svgImageSize])
            cell.myimage.contentMode = .scaleToFill
            cell.myimage.layer.cornerRadius = 50
        }
        else{
            print("Invalid URL - No Image")
            cell.myimage.image = UIImage(named: "empty")

        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "DetailViewController") as? DetailViewController
        vc?.name = countryDataSpaces[indexPath.row].name ?? "nil"
        vc?.code = countryDataSpaces[indexPath.row].code ?? "nil"
        vc?.unicode = countryDataSpaces[indexPath.row].unicode ?? "nil"
        vc?.image = UIImage(named: countryDataSpaces[indexPath.row].image!) ?? UIImage()

        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let detailViewController = storyBoard.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
        self.navigationController?.pushViewController(detailViewController, animated: true)
        
        
        
            
        detailViewController.name = countryDataSpaces[indexPath.row].name ?? "nil"
        detailViewController.code = countryDataSpaces[indexPath.row].code ?? "nil"
        detailViewController.unicode = countryDataSpaces[indexPath.row].unicode ?? "nil"

        print(countryDataSpaces[indexPath.row].image)
        
        let urlImage = URL(string: "\(countryDataSpaces[indexPath.row].image!)")
        let svgCoder = SDImageSVGKCoder.shared
        SDImageCodersManager.shared.addCoder(svgCoder)
        let imageView = UIImageView()
        
        imageView.sd_setImage(with: urlImage)
        // this arg is optional, if don't provide, use the viewport size instead
        let svgImageSize = CGSize(width: 100, height: 100)
        imageView.sd_setImage(with: urlImage, placeholderImage: nil, options: [], context: [.imageThumbnailPixelSize : svgImageSize])
        detailViewController.image = imageView.image ?? UIImage(named: "empty") as! UIImage
            
        
        
    }
    
    
}

extension SDImageFormat{
    public static let SVG: SDImageFormat = SDImageFormat.SVG
    
}


extension ViewController3: UISearchBarDelegate{
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        if searchText == ""
        {
            fetchData.fetchData{CountryDataArray in
                self.countryDataSpaces = CountryDataArray
            }
            
        }
        else{
            countryDataSpaces = countryDataSpaces.filter({ (name) -> Bool in
                return (name.name?.lowercased().contains(searchText.lowercased()))!
                                                            })
        }
        self.tableView.reloadData()
    }
}





