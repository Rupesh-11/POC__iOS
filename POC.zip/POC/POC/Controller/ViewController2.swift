//
//  ViewController2.swift
//  POC
//
//  Created by Pooja on 18/01/23.
//

import UIKit
import CoreData
import ValidatedPropertyKit
import SwiftUI
import KeychainSwift

class ViewController2: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var label1: UILabel!
    

    @IBOutlet weak var name: UITextField!
    

    @IBOutlet weak var Email: UITextField!
    

    @IBOutlet weak var password: UITextField!
    
    var cData = [Credentials]()
    
    @Email1
    var email: String?
    
    @Password1
    var password1: String?

    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        signIn.email == "rupesh@gmail.com"
//        signIn.password == "Rupesh@123"
//        print(signIn.email ?? "--Invalid--", signIn.password ?? "--Invalid--")
//
    }
    
    
    @IBAction func signup(_ sender: Any) {
        signupalert()
    }
    
    @propertyWrapper
    struct Email1<Value: StringProtocol> {
        var value: Value?
        init(wrappedValue value: Value?) {
            self.value = value
        }
        var wrappedValue: Value? {
            get {
                return validate(email: value) ? value : nil
            }
            set {
                value = newValue
            }
        }
        
        private func validate(email: Value?) -> Bool {
            guard let email = email else { return false }
            let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
            let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
            return emailPred.evaluate(with: email)
        }
    }
    
    @propertyWrapper
    struct Password1<Value: StringProtocol> {
        var value: Value?
        init(wrappedValue value: Value?) {
            self.value = value
        }
        var wrappedValue: Value? {
            get {
                return validate(password1: value) ? value : nil
            }
            set {
                value = newValue
            }
        }
        
        private func validate(password1: Value?) -> Bool {
            guard let password1 = password1 else { return false }
            let passwordRegEx = "^(?=.*[a-z])(?=.*[$@$#!%*?&])[A-Za-z\\d$@$#!%*?&]{8,16}"
            let passwordPred = NSPredicate(format:"SELF MATCHES %@", passwordRegEx)
            return passwordPred.evaluate(with: password1)
        }
    }
//    @propertyWrapper
//    struct RegExValidator<T: StringProtocol> {
//        var value: T?
//        var regEx: String
//
//        init(regEx: String, wrappedValue: T) {
//            value = wrappedValue
//            self.regEx = regEx
//        }
//
//        var wrappedValue: T? {
//            get {
//                validate(value: value) ? value : nil
//            }
//            set {
//                value = newValue
//            }
//        }
//
//        private func validate(value: T?) -> Bool {
//            guard let value = value else { return false }
//
//            let predicate = NSPredicate(format:"SELF MATCHES %@", regEx)
//
//                        let result = predicate.evaluate(with: value)
//                        return result
////            return predicate.evaluate(with: value)
//        }
//    }
    
//    struct ValidationLogin {
//    @RegExValidator(regEx: "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{3}", wrappedValue: "")
//        var email: String?
//    @RegExValidator(regEx: "^(?=.*[a-z])(?=.*[$@$#!%*?&])[A-Za-z\\d$@$#!%*?&]{8,16}",
//    wrappedValue: "")
//        var password: String?
//    }
//
//    var signIn = ValidationLogin()
    
    func showAlert(message:String){
    let alertController = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        let ok = UIAlertAction(title: "Ok", style: .default)
        alertController.addAction(ok)
        self.present(alertController, animated: true)
    }
    
    
    
    func signupalert(){
        
        email = Email.text!
        password1 = password.text!
        
        if let textname = self.name.text, textname.isEmpty && Email.text?.isEmpty == true && password.text?.isEmpty == true {
            showAlert(message: "Please enter all fields")
        }
        
        else if name.text?.isEmpty == false && Email.text?.isEmpty == true && password.text?.isEmpty == true{
            showAlert(message: "Kindly enter Email and Password")
        }
        
        else if name.text?.isEmpty == true && Email.text?.isEmpty == false && password.text?.isEmpty == true{
            showAlert(message: "Kindly enter Name and Password")
            
        }
        else if name.text?.isEmpty == true && Email.text?.isEmpty == true && password.text?.isEmpty == false{
            showAlert(message: "Kindly enter Name and Email")
        }
        
        else if let textname = self.name.text, textname.isEmpty
        {
            showAlert(message: "Your name is empty")
        }
        
        else if let textEmail = self.Email.text, textEmail.isEmpty{
            showAlert(message: "Your email is empty")
        }
        
        else if let textpassword = self.password.text, textpassword.isEmpty{
            showAlert(message: "Your password is empty")
        }
        
        
        else if (email == nil) {
            showAlert(message: "Your email is invalid")
        }
        
        else if (password1 == nil){
            showAlert(message: "Your Password is invalid. It should be 8-16 length with atleast one alphabet and one special character")
       }
        
//        else if Email.text == Credentials[IndexPath.row].Email {
//
//        }
        
        else{
            
        let appDe = (UIApplication.shared.delegate) as! AppDelegate
        let context = appDe.persistentContainer.viewContext
        let credential = NSEntityDescription.insertNewObject(forEntityName: "Credentials", into: context) as! Credentials
            credential.setValue(name.text, forKey: "name")
            credential.setValue(Email.text, forKey: "email")
            credential.setValue(password.text, forKey: "password")
        //credential.name = name.text
        //credential.email = Email.text
        //credential.password = password.text
            
            
        do{
//            guard let userName = self.Email.text,
//                  let Password = self.password.text else { return }
//
//            let keychain = KeychainSwift()
//            keychain.accessGroup = "123ABCXYZ.iOSAppTemplates"
//            keychain.set(userName, forKey: "userName")
//            keychain.set(Password, forKey: "password")
            

            
            try context.save()
            print("Data saved successfully")
            name.text = ""
            Email.text = ""
            password.text = ""
            let alert = UIAlertController(title: "Wow!", message: "Registration successful", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: {(action) -> Void in
                let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
                            let viewController = storyBoard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
                            self.present(viewController, animated:true, completion:nil)
            }))
            present(alert, animated: true, completion:{
                return
            })
        }
        catch{
            let alert = UIAlertController(title: "Sorry!", message: "Error Occured while saving the data", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion:{
                return
            })
            print("Error Occured while saving data")
        }
        }
        
    }
    
    
    @IBAction func btn2(_ sender: Any) {
    }
    
  
    
}


extension String{

    //Validate email address logic
    var isValidEmail: Bool {
            //Declaring the rule of characters to be used. Applying rule to current state. Verifying the result.
            let regex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{3}"
            let test = NSPredicate(format: "SELF MATCHES %@", regex)
            let result = test.evaluate(with: self)
            return result
        }


        //    length 8 to 16.
        //    One Alphabet in Password.
        //    One Special Character in Password.

    var isValidPassword: Bool {
            let passwordRegEx = "^(?=.*[a-z])(?=.*[$@$#!%*?&])[A-Za-z\\d$@$#!%*?&]{8,16}"
            let passwordTest = NSPredicate(format:"SELF MATCHES %@", passwordRegEx)
            let result = passwordTest.evaluate(with: self)
            return result
        }

}


