//
//  MyTableViewCell.swift
//  POC
//
//  Created by Rupesh on 27/01/23.
//

import UIKit

class MyTableViewCell: UITableViewCell {
    
    
    
    @IBOutlet weak var myimage: UIImageView!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var codeLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        myimage.image = nil
    }

}
