//
//  DetailViewController.swift
//  POC
//
//  Created by Rupesh on 30/01/23.
//

import UIKit

class DetailViewController: UIViewController {
    
    @IBOutlet weak var labelname: UILabel!
    
    @IBOutlet weak var img: UIImageView!
    
    @IBOutlet weak var labelcode: UILabel!
    
    @IBOutlet weak var labelunicode: UILabel!
    
    var name: String = ""
    var image = UIImage()
    
    var code: String = ""
    var unicode: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        labelname.text = "\(name)"
        img.image = image
        labelcode.text = "\(code)"
        labelunicode.text = "\(unicode)"

        // Do any additional setup after loading the view.
    }
    
    @IBAction func back(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
        
    }
    
    
    
    @IBAction func logout(_ sender: Any) {
        let alert = UIAlertController(title: "Alert", message: "Are you sure want to logout!", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler:{ (action) -> Void in
            
            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
                        let viewController = storyBoard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
                        self.present(viewController, animated:true, completion:nil)
                        
    }
        ))
        alert.addAction(UIAlertAction(title: "Cancel", style: .default, handler:nil
            
        ))
        present(alert, animated: true, completion:{
            return
        })    }
    
    
    


}
