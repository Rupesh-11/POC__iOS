//
//  Credentials+CoreDataClass.swift
//  POC
//
//  Created by Pooja on 19/01/23.
//
//

import Foundation
import CoreData


public class Credentials: NSManagedObject {

}
