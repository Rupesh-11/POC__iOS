//
//  CountryData.swift
//  POC
//
//  Created by Rupesh on 27/01/23.
//

import Foundation

struct  CountryData : Codable {
    let name : String?
    let code : String?
    let emoji : String?
    let unicode : String?
    let image : String?
}
