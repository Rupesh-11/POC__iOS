//
//  FetchData.swift
//  POC
//
//  Created by Pooja on 27/01/23.
//

import Foundation

class FetchData{

func fetchData(CompletionHandler:@escaping ([CountryData]) -> Void)
{
    var countryDataSpaces = [CountryData]()
    let urlForFetchingdata = "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/index.json"
    if let urlToServer = URL.init(string: urlForFetchingdata)
    {
        let task = URLSession.shared.dataTask(with: urlToServer, completionHandler: {(data, response, error) in
            if error != nil || data == nil{
                print("An error occured while fetching data from API")
            }
            else{
                if let responseText = String.init(data:data! , encoding: .ascii){
                    let  jsonData = responseText.data(using: .utf8)!
                    countryDataSpaces = try! JSONDecoder().decode([CountryData].self, from: jsonData)
                    CompletionHandler(countryDataSpaces)
                    
               
                }
                
            }
        })
        task.resume()
        
    }
    
    
    CompletionHandler(countryDataSpaces)
}
}
